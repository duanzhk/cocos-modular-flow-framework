'use strict';

module.exports = {
    'description': 'dzkcc-mflow框架配套的UI工具。可以创建对应脚本，并自动引用prefab上需要操作的元素。',
    'generate-base-ui': '生成预置体脚本',
    'generate-mapping': '生成API类型提示',
};
